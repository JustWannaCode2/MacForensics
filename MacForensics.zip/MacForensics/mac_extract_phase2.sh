#!/usr/bin/env bash
# mac_extract_phase2.sh — Search & correlate IOCs in a Phase 1 mac_extract_* collection
#
# Usage (IOC mode):
#   /bin/bash mac_extract_phase2.sh /tmp/mac_extract_YYYYmmdd_HHMMSS "chatgpt.com"
#   /bin/bash mac_extract_phase2.sh "chatgpt.com"            # auto-detect latest /tmp/mac_extract_*
#
# Usage (Scareware mode — built-in rules):
#   /bin/bash mac_extract_phase2.sh /tmp/mac_extract_YYYYmmdd_HHMMSS --scareware
#   /bin/bash mac_extract_phase2.sh --scareware              # auto-detect latest /tmp/mac_extract_*
#
# Optional time filter (SCAREWARE mode only):
#   -d N      => last N days      (e.g. -d 2  for last 2 days)
#   -t DUR    => duration, where DUR is like 90m, 1h, 30s, 3d, etc.
#                units: s = seconds, m = minutes, h = hours, d = days
#
# Examples:
#   /bin/bash mac_extract_phase2.sh /tmp/mac_extract_YYYYmmdd_HHMMSS --scareware -d 2
#   /bin/bash mac_extract_phase2.sh --scareware -t 90m
#
# Output:
#   <Phase1>/phase2_results_<ts>/
#     ├─ hits/*.csv      (was *.txt)
#     ├─ timeline.tsv
#     ├─ summary.txt
#     └─ report.md

set -euo pipefail

has_cmd(){ command -v "$1" >/dev/null 2>&1; }
err(){ echo "[-] $*" >&2; exit 1; }

is_dir(){ [[ -d "${1:-}" ]]; }
is_tgz(){ [[ "${1:-}" == *.tgz ]]; }

# -------------------- Scareware signatures --------------------
SCARE_TERMS=(
  # Generic panic / infection language
  "critical"
  "critical alert"
  "virus"
  "alert"
  "security alert"
  "security warning"
  "warning"
  "urgent"
  "immediate action required"
  "immediate"
  "action required"
  "your computer is at risk"
  "your system is at risk"
  "at risk"
  "system infected"
  "infected"
  "system"
  "system damage"
  "virus detected"
  "malware detected"
  "malware"
  "threat"
  "risk"
  "threats found"
  "high risk"
  "severe threat"
  "suspicious"
  "disable"
  "lock"
  "pc"
  "antivirus"
  "defender"
  "microsoft"
  "security center"
  "support"

  # Fake infection messages
  "your computer is infected"
  "your pc is infected"
  "your mac is infected"
  "your device is infected"
  "your computer has been blocked"
  "your browser has been locked"
  "suspicious activity detected"
  "unauthorized access detected"
  "do not close this page"
  "do not shut down your computer"
  "do not ignore this message"
  "your computer will be disabled"
  "access to this pc has been blocked"
  "protection"
  "subscription"

  # Fake AV / security product names often abused
  "mcafee"
  "norton"
  "norton antivirus"
  "norton security"
  "avast"
  "avg"
  "bitdefender"
  "kaspersky"
  "totalav"
  "webroot"
  "trend micro"
  "pc matic"
  "advanced system repair"
  "windows defender"
  "windows defender security center"
  "microsoft defender"

  # Vendor / support impersonation
  "microsoft support"
  "microsoft certified technician"
  "microsoft security"
  "apple support"
  "applecare"
  "apple security"
  "call microsoft support"
  "call apple support"
  "contact microsoft support"
  "contact apple support"
  "support hotline"
  "tech support"
  "technical support"
  "remote support"

  
  # Subscription / payment pressure
  "subscription expired"
  "your subscription has expired"
  "license expired"
  "protection expired"
  "subscription renewal required"
  "auto renewal"
  "auto-renewal"
  "renew now"
  "reactivate protection"
  "activate now"
  "activate your protection"
  "renew subscription"
  "update your billing information"
  "confirm your payment details"

  # Clean / fix your PC lures
  "clean your mac"
  "clean your pc"
  "optimize your mac"
  "optimize your pc"
  "fix your pc"
  "fix your mac"
  "repair your pc"
  "repair your mac"
  "system optimizer"
  "pc cleaner"
  "registry cleaner"
)

SCARE_REGEX=""

build_scare_regex() {
  local first=1 esc
  for t in "${SCARE_TERMS[@]}"; do
    esc="$(printf '%s' "$t" | sed 's/[].[^$*+?{}()|\\/]/\\&/g')"
    if [[ $first -eq 1 ]]; then
      SCARE_REGEX="$esc"
      first=0
    else
      SCARE_REGEX="${SCARE_REGEX}|${esc}"
    fi
  done
}

# -------------------- Time filter helpers (SCAREWARE only) --------------------
TIME_FILTER_SECS=""
TIME_CUTOFF_EPOCH=""
TIME_CUTOFF_ISO=""

parse_duration() {
  local s="$1" num unit
  if [[ "$s" =~ ^([0-9]+)([smhd])$ ]]; then
    num="${BASH_REMATCH[1]}"
    unit="${BASH_REMATCH[2]}"
    case "$unit" in
      s) echo "$num" ;;
      m) echo $(( num * 60 )) ;;
      h) echo $(( num * 3600 )) ;;
      d) echo $(( num * 86400 )) ;;
      *) return 1 ;;
    esac
  else
    return 1
  fi
}

init_time_filter() {
  [[ -z "${TIME_FILTER_SECS:-}" ]] && return 0
  local now
  now="$(date +%s)"
  TIME_CUTOFF_EPOCH=$(( now - TIME_FILTER_SECS ))
  TIME_CUTOFF_ISO="$(date -r "$TIME_CUTOFF_EPOCH" '+%Y-%m-%d %H:%M:%S' 2>/dev/null || \
                     date -u -r "$TIME_CUTOFF_EPOCH" '+%Y-%m-%d %H:%M:%S' 2>/dev/null || \
                     echo "")"
}

# -------------------- Parse args --------------------
PHASE1_IN=""
IOC=""
MODE="IOC"   # or "SCAREWARE"

if [[ $# -eq 0 ]]; then
  echo "Usage:"
  echo "  /bin/bash $0 /tmp/mac_extract_YYYYmmdd_HHMMSS \"ioc-string\""
  echo "  /bin/bash $0 \"ioc-string\""
  echo "  /bin/bash $0 /tmp/mac_extract_YYYYmmdd_HHMMSS --scareware [-d N | -t DUR]"
  echo "  /bin/bash $0 --scareware [-d N | -t DUR]"
  exit 1
fi

while [[ $# -gt 0 ]]; do
  case "$1" in
    --scareware)
      MODE="SCAREWARE"
      shift
      ;;
    -d|--days)
      [[ $# -lt 2 ]] && err "-d/--days requires a number (e.g. -d 2)"
      shift
      [[ "$1" =~ ^[0-9]+$ ]] || err "Days must be an integer (got '$1')"
      TIME_FILTER_SECS=$(( $1 * 86400 ))
      shift
      ;;
    -t|--time)
      [[ $# -lt 2 ]] && err "-t/--time requires a duration like 90m, 1h, 30s, 3d"
      shift
      local_dur="$1"
      shift
      secs="$(parse_duration "$local_dur" || true)"
      [[ -n "${secs:-}" ]] || err "Invalid duration '$local_dur' (expected e.g. 90m, 1h, 2d)"
      TIME_FILTER_SECS="$secs"
      ;;
    *)
      if [[ -z "$PHASE1_IN" && ( "$1" == /tmp/mac_extract_* || "$1" == *.tgz ) ]]; then
        PHASE1_IN="$1"
        shift
      elif [[ -z "$IOC" && "$MODE" == "IOC" ]]; then
        IOC="$1"
        shift
      else
        err "Unexpected argument: $1"
      fi
      ;;
  esac
done

if [[ "$MODE" == "IOC" && -z "${IOC:-}" ]]; then
  err "Provide an IOC (e.g. domain, filename) or use --scareware."
fi

if [[ "$MODE" == "SCAREWARE" ]]; then
  IOC="scareware"
  build_scare_regex
  [[ -n "${TIME_FILTER_SECS:-}" ]] && init_time_filter
fi

# -------------------- Resolve Phase-1 directory --------------------
PHASE1_DIR=""
WORK_TMP=""

if [[ -n "$PHASE1_IN" ]]; then
  if is_dir "$PHASE1_IN"; then
    PHASE1_DIR="$PHASE1_IN"
  elif is_tgz "$PHASE1_IN"; then
    WORK_TMP="$(mktemp -d /tmp/_phase2_extract_XXXXXX)"
    echo "[*] Extracting tarball: $PHASE1_IN -> $WORK_TMP"
    tar -xzf "$PHASE1_IN" -C "$WORK_TMP"
    PHASE1_DIR="$(find "$WORK_TMP" -maxdepth 1 -type d -name 'mac_extract_*' -print -quit)"
    [[ -n "$PHASE1_DIR" ]] || err "Could not find extracted mac_extract_* folder in $WORK_TMP"
  else
    err "Given path is neither a folder nor a .tgz: $PHASE1_IN"
  fi
else
  PHASE1_DIR="$(find /tmp -maxdepth 1 -type d -name 'mac_extract_*' -print0 | xargs -0 ls -td 2>/dev/null | head -1 || true)"
  [[ -n "$PHASE1_DIR" ]] || err "No mac_extract_* folder found in /tmp. Provide the Phase-1 folder explicitly."
fi

[[ -d "$PHASE1_DIR" ]] || err "Phase-1 folder not found: $PHASE1_DIR"

TS="$(date +%Y%m%d_%H%M%S)"
OUT_DIR="$PHASE1_DIR/phase2_results_${TS}"
mkdir -p "$OUT_DIR/hits"

IOC_DISP="$IOC"
echo "[*] Results directory  : $OUT_DIR"
echo "[*] Using Phase-1 folder: $PHASE1_DIR"
echo "[*] Mode               : $MODE"
echo "[*] Searching for      : $IOC_DISP"
if [[ "$MODE" == "SCAREWARE" && -n "${TIME_FILTER_SECS:-}" ]]; then
  echo "[*] Time filter        : last ${TIME_FILTER_SECS}s (cutoff epoch=${TIME_CUTOFF_EPOCH}, iso=${TIME_CUTOFF_ISO})"
fi

# -------------------- Helpers --------------------
add_tl(){ # time_iso  source  evidence  filepath
  printf "%s\t%s\t%s\t%s\n" "$1" "$2" "$3" "$4" >> "$OUT_DIR/timeline.tsv"
}

echo -e "time_iso\tsource\tevidence\tfilepath" > "$OUT_DIR/timeline.tsv"

gri_ioc(){  grep -Rni -- "$IOC" "$1" 2>/dev/null || true; }
gri_scare(){ grep -Rni -E -- "$SCARE_REGEX" "$1" 2>/dev/null || true; }

AWK_PATTERN="$IOC"
if [[ "$MODE" == "SCAREWARE" ]]; then
  AWK_PATTERN="$SCARE_REGEX"
fi

# -------------------- 1) Quarantine --------------------
echo "[*] Quarantine..."
if [[ "$MODE" == "IOC" ]]; then
  if [[ -d "$PHASE1_DIR/Quarantine" ]]; then
    gri_ioc "$PHASE1_DIR/Quarantine" | tee "$OUT_DIR/hits/quarantine_hits.txt" >/dev/null
    if [[ -s "$OUT_DIR/hits/quarantine_hits.txt" ]]; then
      while IFS= read -r line; do
        add_tl "" "quarantine" "$line" "$PHASE1_DIR/Quarantine"
      done < "$OUT_DIR/hits/quarantine_hits.txt"
    fi
  fi
else
  echo "[*] Skipping Quarantine in scareware mode (not typically scareware-specific)."
fi

# -------------------- 2) Chrome (Default) --------------------
echo "[*] Chrome (Default)..."
CHROME="$PHASE1_DIR/Chrome_Default"
if [[ -d "$CHROME" ]]; then
  if [[ "$MODE" == "IOC" ]]; then
    [[ -f "$CHROME/URLs.csv" ]]      && gri_ioc "$CHROME/URLs.csv"      | tee "$OUT_DIR/hits/chrome_urls_hits.txt" >/dev/null
    [[ -f "$CHROME/Downloads.csv" ]] && gri_ioc "$CHROME/Downloads.csv" | tee "$OUT_DIR/hits/chrome_downloads_hits.txt" >/dev/null
  else
    [[ -f "$CHROME/URLs.csv" ]]      && gri_scare "$CHROME/URLs.csv"      | tee "$OUT_DIR/hits/chrome_urls_hits_scareware.txt" >/dev/null
    [[ -f "$CHROME/Downloads.csv" ]] && gri_scare "$CHROME/Downloads.csv" | tee "$OUT_DIR/hits/chrome_downloads_hits_scareware.txt" >/dev/null
  fi

  if [[ -f "$CHROME/URLs.csv" ]]; then
    if [[ "$MODE" == "IOC" ]]; then
      awk -F, -v IGNORECASE=1 -v pattern="$AWK_PATTERN" \
        'NR>1 && $0 ~ pattern {
           gsub(/"/,"",$2);
           print $2 "\tchrome_urls\tvisit " $1 "\tF:Chrome_Default/URLs.csv"
         }' \
        "$CHROME/URLs.csv" >> "$OUT_DIR/timeline.tsv" 2>/dev/null || true
    else
      awk -F, -v IGNORECASE=1 -v pat="$SCARE_REGEX" -v cutoff="${TIME_CUTOFF_EPOCH:-0}" '
        NR==1 { next }
        $0 ~ pat {
          t=$2; gsub(/"/,"",t)
          if (cutoff > 0) {
            cmd = "date -j -f \"%Y-%m-%d %H:%M:%S\" \"" t "\" +%s 2>/dev/null"
            cmd | getline ts
            close(cmd)
            if (ts+0 < cutoff) next
          }
          url=$1; gsub(/"/,"",url)
          print t "\tchrome_urls\tvisit " url "\tF:Chrome_Default/URLs.csv"
        }' "$CHROME/URLs.csv" >> "$OUT_DIR/timeline.tsv" 2>/dev/null || true
    fi
  fi

  if [[ -f "$CHROME/Downloads.csv" ]]; then
    if [[ "$MODE" == "IOC" ]]; then
      awk -F, -v IGNORECASE=1 -v pattern="$AWK_PATTERN" \
        'NR>1 && $0 ~ pattern {
           gsub(/"/,"",$5);
           print $5 "\tchrome_downloads\tdownload target=" $1 " tab=" $3 " danger=" $4 "\tF:Chrome_Default/Downloads.csv"
         }' \
        "$CHROME/Downloads.csv" >> "$OUT_DIR/timeline.tsv" 2>/dev/null || true
    else
      awk -F, -v IGNORECASE=1 -v pat="$SCARE_REGEX" -v cutoff="${TIME_CUTOFF_EPOCH:-0}" '
        NR==1 { next }
        $0 ~ pat {
          t=$5; gsub(/"/,"",t)
          if (cutoff > 0) {
            cmd = "date -j -f \"%Y-%m-%d %H:%M:%S\" \"" t "\" +%s 2>/dev/null"
            cmd | getline ts
            close(cmd)
            if (ts+0 < cutoff) next
          }
          target=$1; tab=$3; danger=$4
          gsub(/"/,"",target); gsub(/"/,"",tab); gsub(/"/,"",danger)
          print t "\tchrome_downloads\tdownload target=" target " tab=" tab " danger=" danger "\tF:Chrome_Default/Downloads.csv"
        }' "$CHROME/Downloads.csv" >> "$OUT_DIR/timeline.tsv" 2>/dev/null || true
    fi
  fi
fi

# -------------------- 2b) Edge (Default) --------------------
echo "[*] Edge (Default)..."
EDGE="$PHASE1_DIR/Edge_Default"
if [[ -d "$EDGE" ]]; then
  if [[ "$MODE" == "IOC" ]]; then
    [[ -f "$EDGE/URLs.csv" ]]      && gri_ioc "$EDGE/URLs.csv"      | tee "$OUT_DIR/hits/edge_urls_hits.txt" >/dev/null
    [[ -f "$EDGE/Downloads.csv" ]] && gri_ioc "$EDGE/Downloads.csv" | tee "$OUT_DIR/hits/edge_downloads_hits.txt" >/dev/null
  else
    [[ -f "$EDGE/URLs.csv" ]]      && gri_scare "$EDGE/URLs.csv"      | tee "$OUT_DIR/hits/edge_urls_hits_scareware.txt" >/dev/null
    [[ -f "$EDGE/Downloads.csv" ]] && gri_scare "$EDGE/Downloads.csv" | tee "$OUT_DIR/hits/edge_downloads_hits_scareware.txt" >/dev/null
  fi

  if [[ -f "$EDGE/URLs.csv" ]]; then
    if [[ "$MODE" == "IOC" ]]; then
      awk -F, -v IGNORECASE=1 -v pattern="$AWK_PATTERN" \
        'NR>1 && $0 ~ pattern {
           gsub(/"/,"",$2);
           print $2 "\tedge_urls\tvisit " $1 "\tF:Edge_Default/URLs.csv"
         }' \
        "$EDGE/URLs.csv" >> "$OUT_DIR/timeline.tsv" 2>/dev/null || true
    else
      awk -F, -v IGNORECASE=1 -v pat="$SCARE_REGEX" -v cutoff="${TIME_CUTOFF_EPOCH:-0}" '
        NR==1 { next }
        $0 ~ pat {
          t=$2; gsub(/"/,"",t)
          if (cutoff > 0) {
            cmd = "date -j -f \"%Y-%m-%d %H:%M:%S\" \"" t "\" +%s 2>/dev/null"
            cmd | getline ts
            close(cmd)
            if (ts+0 < cutoff) next
          }
          url=$1; gsub(/"/,"",url)
          print t "\tedge_urls\tvisit " url "\tF:Edge_Default/URLs.csv"
        }' "$EDGE/URLs.csv" >> "$OUT_DIR/timeline.tsv" 2>/dev/null || true
    fi
  fi

  if [[ -f "$EDGE/Downloads.csv" ]]; then
    if [[ "$MODE" == "IOC" ]]; then
      awk -F, -v IGNORECASE=1 -v pattern="$AWK_PATTERN" \
        'NR>1 && $0 ~ pattern {
           gsub(/"/,"",$5);
           print $5 "\tedge_downloads\tdownload target=" $1 " tab=" $3 " danger=" $4 "\tF:Edge_Default/Downloads.csv"
         }' \
        "$EDGE/Downloads.csv" >> "$OUT_DIR/timeline.tsv" 2>/dev/null || true
    else
      awk -F, -v IGNORECASE=1 -v pat="$SCARE_REGEX" -v cutoff="${TIME_CUTOFF_EPOCH:-0}" '
        NR==1 { next }
        $0 ~ pat {
          t=$5; gsub(/"/,"",t)
          if (cutoff > 0) {
            cmd = "date -j -f \"%Y-%m-%d %H:%M:%S\" \"" t "\" +%s 2>/dev/null"
            cmd | getline ts
            close(cmd)
            if (ts+0 < cutoff) next
          }
          target=$1; tab=$3; danger=$4
          gsub(/"/,"",target); gsub(/"/,"",tab); gsub(/"/,"",danger)
          print t "\tedge_downloads\tdownload target=" target " tab=" tab " danger=" danger "\tF:Edge_Default/Downloads.csv"
        }' "$EDGE/Downloads.csv" >> "$OUT_DIR/timeline.tsv" 2>/dev/null || true
    fi
  fi
fi

# -------------------- 3) Safari --------------------
echo "[*] Safari..."
SAF="$PHASE1_DIR/Safari"
if [[ -d "$SAF" ]]; then
  if [[ "$MODE" == "IOC" ]]; then
    gri_ioc "$SAF" | tee "$OUT_DIR/hits/safari_hits.txt" >/dev/null
  else
    gri_scare "$SAF" | tee "$OUT_DIR/hits/safari_hits_scareware.txt" >/dev/null
  fi

  if [[ -f "$SAF/Safari_History.csv" ]]; then
    if [[ "$MODE" == "IOC" ]]; then
      awk -F, -v IGNORECASE=1 -v pattern="$AWK_PATTERN" \
        'NR>1 && $0 ~ pattern {
           gsub(/"/,"",$2);
           print $2 "\tsafari_history\tvisit " $1 "\tF:Safari/Safari_History.csv"
         }' \
        "$SAF/Safari_History.csv" >> "$OUT_DIR/timeline.tsv" 2>/dev/null || true
    else
      awk -F, -v IGNORECASE=1 -v pat="$SCARE_REGEX" -v cutoff="${TIME_CUTOFF_EPOCH:-0}" '
        NR==1 { next }
        $0 ~ pat {
          t=$2; gsub(/"/,"",t)
          if (cutoff > 0) {
            cmd = "date -j -f \"%Y-%m-%d %H:%M:%S\" \"" t "\" +%s 2>/dev/null"
            cmd | getline ts
            close(cmd)
            if (ts+0 < cutoff) next
          }
          url=$1; gsub(/"/,"",url)
          print t "\tsafari_history\tvisit " url "\tF:Safari/Safari_History.csv"
        }' "$SAF/Safari_History.csv" >> "$OUT_DIR/timeline.tsv" 2>/dev/null || true
    fi
  fi
fi

# -------------------- 4) Firefox --------------------
echo "[*] Firefox..."
FF="$PHASE1_DIR/Firefox"
if [[ -d "$FF" ]]; then
  find "$FF" -type f -name "places.csv" -print0 2>/dev/null | while IFS= read -r -d '' f; do
    if [[ "$MODE" == "IOC" ]]; then
      gri_ioc "$f" | tee -a "$OUT_DIR/hits/firefox_hits.txt" >/dev/null
      awk -F, -v IGNORECASE=1 -v pattern="$AWK_PATTERN" \
        'NR>1 && $0 ~ pattern {
           gsub(/"/,"",$2);
           print $2 "\tfirefox_history\tvisit " $1 "\tF:'"$f"'"
         }' \
        "$f" >> "$OUT_DIR/timeline.tsv" 2>/dev/null || true
    else
      gri_scare "$f" | tee -a "$OUT_DIR/hits/firefox_hits_scareware.txt" >/dev/null
      awk -F, -v IGNORECASE=1 -v pat="$SCARE_REGEX" -v cutoff="${TIME_CUTOFF_EPOCH:-0}" \
        -v path="$f" '
        NR==1 { next }
        $0 ~ pat {
          t=$2; gsub(/"/,"",t)
          if (cutoff > 0) {
            cmd = "date -j -f \"%Y-%m-%d %H:%M:%S\" \"" t "\" +%s 2>/dev/null"
            cmd | getline ts
            close(cmd)
            if (ts+0 < cutoff) next
          }
          url=$1; gsub(/"/,"",url)
          print t "\tfirefox_history\tvisit " url "\tF:" path
        }' "$f" >> "$OUT_DIR/timeline.tsv" 2>/dev/null || true
    fi
  done
fi

# -------------------- 5) Downloads metadata --------------------
echo "[*] Downloads metadata..."
DMD="$PHASE1_DIR/Downloads"
if [[ -d "$DMD" ]]; then
  if [[ "$MODE" == "IOC" ]]; then
    gri_ioc "$DMD" | tee "$OUT_DIR/hits/downloads_metadata_hits.txt" >/dev/null
  else
    gri_scare "$DMD" | tee "$OUT_DIR/hits/downloads_metadata_hits_scareware.txt" >/dev/null
  fi
fi

# -------------------- 6) Unified Logs (IOC mode only) --------------------
echo "[*] Unified Logs..."
UARCH="$(find "$PHASE1_DIR/UnifiedLogs" -maxdepth 1 -type d -name '*.logarchive' -print -quit 2>/dev/null || true)"

if [[ "$MODE" == "IOC" && -n "${UARCH:-}" ]] && has_cmd log; then
  log show --archive "$UARCH" --info --predicate "eventMessage CONTAINS[c] \"$IOC\"" --style syslog \
    > "$OUT_DIR/hits/unified_general.txt" 2>/dev/null || true

  log show --archive "$UARCH" --info --predicate 'process == "mDNSResponder" AND eventMessage CONTAINS[c] "'"$IOC"'"' --style syslog \
    > "$OUT_DIR/hits/unified_dns.txt" 2>/dev/null || true

  log show --archive "$UARCH" --info --predicate 'process == "trustd" AND eventMessage CONTAINS[c] "'"$IOC"'"' --style syslog \
    > "$OUT_DIR/hits/unified_tls.txt" 2>/dev/null || true

  for f in unified_general.txt unified_dns.txt unified_tls.txt; do
    [[ -s "$OUT_DIR/hits/$f" ]] || continue
    awk '
      BEGIN{FS="[[:space:]]+"}
      /^[0-9]{4}-[0-9]{2}-[0-9]{2}/{
        ts=$1" "$2; sub(/\..*/,"",ts);
        print ts "\t" "'"${f%.txt}"'" "\t" $0 "\t" "'"$UARCH"'"
      }' "$OUT_DIR/hits/$f" >> "$OUT_DIR/timeline.tsv" || true
  done
elif [[ "$MODE" == "SCAREWARE" ]]; then
  echo "[*] Skipping unified logs in scareware mode (focused on browser & download artifacts)."
else
  echo "[*] No .logarchive found or 'log' tool unavailable; skipping unified logs."
fi

# -------------------- 7) Execution Forensics (IOC mode only) --------------------
echo "[*] Execution artifacts..."
if [[ "$MODE" == "IOC" && -n "${UARCH:-}" ]] && has_cmd log; then
  log show --archive "$UARCH" --info --predicate "eventMessage CONTAINS[c] \"$IOC\" AND (eventMessage CONTAINS[c] \"exec\" OR eventMessage CONTAINS[c] \"launched\")" --style syslog \
    > "$OUT_DIR/hits/unified_exec.txt" 2>/dev/null || true

  if [[ -s "$OUT_DIR/hits/unified_exec.txt" ]]; then
    awk '
      BEGIN{FS="[[:space:]]+"}
      /^[0-9]{4}-[0-9]{2}-[0-9]{2}/{
        ts=$1" "$2; sub(/\..*/,"",ts);
        print ts "\t" "unified_exec" "\t" $0 "\t" "'"$UARCH"'"
      }' "$OUT_DIR/hits/unified_exec.txt" >> "$OUT_DIR/timeline.tsv" || true
  fi
else
  echo "[*] Unified logs unavailable or scareware mode enabled; skipping execution search."
fi

# -------------------- 8) Sort timeline --------------------
{ read -r header; echo "$header"; sort -k1,1 -k2,2; } < "$OUT_DIR/timeline.tsv" > "$OUT_DIR/timeline.sorted.tsv" || true
mv "$OUT_DIR/timeline.sorted.tsv" "$OUT_DIR/timeline.tsv" || true

# -------------------- 9) Derive scareware hit files from timeline (time-filtered) --------------------
if [[ "$MODE" == "SCAREWARE" ]]; then
  awk -F'\t' -v outdir="$OUT_DIR" '
    NR==1 { next }
    {
      src = $2
      gsub(/[^A-Za-z0-9_-]/,"_",src)
      fname = outdir "/hits/" src "_hits_scareware.txt"
      print $0 >> fname
    }
  ' "$OUT_DIR/timeline.tsv" 2>/dev/null || true
fi

# -------------------- 10) Convert all hits from .txt to .csv --------------------
for f in "$OUT_DIR"/hits/*.txt; do
  [[ -e "$f" ]] || continue
  mv "$f" "${f%.txt}.csv"
done

# -------------------- 11) Summary & report --------------------
{
  echo "Mode      : $MODE"
  echo "Search    : $IOC_DISP"
  echo "Phase-1   : $PHASE1_DIR"
  if [[ "$MODE" == "SCAREWARE" && -n "${TIME_FILTER_SECS:-}" ]]; then
    echo "TimeRange : last ${TIME_FILTER_SECS}s (cutoff epoch=${TIME_CUTOFF_EPOCH}, iso=${TIME_CUTOFF_ISO})"
  fi
  echo ""
  echo "==============================="
  echo "Total hits (from hits/*.csv)"
  echo "==============================="
  for f in "$OUT_DIR"/hits/*.csv; do
    [[ -e "$f" ]] || continue
    if [[ "$MODE" == "IOC" ]]; then
      n="$(grep -ic -- "$IOC" "$f" 2>/dev/null || true)"
    else
      n="$(grep -Eic -- "$SCARE_REGEX" "$f" 2>/dev/null || true)"
    fi
    [[ "$n" =~ ^[0-9]+$ ]] || n=0
    printf "%-32s : %s\n" "$(basename "$f")" "$n"
  done

  echo ""
  echo "==============================="
  echo "Total hits by source (from timeline.tsv)"
  echo "==============================="
  awk -F'\t' 'NR>1 {cnt[$2]++} END {for (k in cnt) printf "%-20s : %d\n", k, cnt[k]}' \
    "$OUT_DIR/timeline.tsv" 2>/dev/null || true
} | tee "$OUT_DIR/summary.txt"

{
  echo "# mac_extract_phase2 report"
  echo ""
  echo "**Mode:** \`$MODE\`  "
  echo "**Search:** \`$IOC_DISP\`  "
  echo "**Phase-1 folder:** \`$PHASE1_DIR\`  "
  if [[ "$MODE" == "SCAREWARE" && -n "${TIME_FILTER_SECS:-}" ]]; then
    echo "**TimeRange:** last ${TIME_FILTER_SECS}s (cutoff epoch=${TIME_CUTOFF_EPOCH}, iso=${TIME_CUTOFF_ISO})  "
  fi
  echo ""
  echo "## Summary"
  echo '```'
  cat "$OUT_DIR/summary.txt"
  echo '```'
  echo ""
  echo "## Timeline (first 100 rows)"
  echo '```tsv'
  head -n 101 "$OUT_DIR/timeline.tsv"
  echo '```'
  echo ""
  echo "## Hit Files"
  for f in "$OUT_DIR"/hits/*.csv; do
    echo "- $(basename "$f")"
  done
} > "$OUT_DIR/report.md"

echo ""
echo "=== DONE ==="
echo "Summary : $OUT_DIR/summary.txt"
echo "Timeline: $OUT_DIR/timeline.tsv"
echo "Report  : $OUT_DIR/report.md"
echo "Hits    : $OUT_DIR/hits/"
[[ -n "${WORK_TMP:-}" ]] && rm -rf "$WORK_TMP" || true
