#!/usr/bin/env bash
# mac_extract_phase2.sh — Search & correlate IOCs in a Phase 1 mac_extract_* collection
#
# Usage:
#   sudo /bin/bash mac_extract_phase2.sh /tmp/mac_extract_YYYYmmdd_HHMMSS "chatgpt.com" [OUT_BASE_DIR]
#   sudo /bin/bash mac_extract_phase2.sh "invoice.pdf" [OUT_BASE_DIR]     # auto-detect newest /tmp/mac_extract_* folder
#
# Output:
#   <OUT_BASE_DIR or $PWD>/phase2_results_<ts>/
#     ├─ hits/*.txt
#     ├─ timeline.tsv
#     ├─ summary.txt
#     └─ report.md

set -euo pipefail

has_cmd(){ command -v "$1" >/dev/null 2>&1; }
err(){ echo "[-] $*" >&2; exit 1; }

# -------------------- Parse args --------------------
PHASE1_IN="" ; IOC="" ; OUT_BASE=""
case $# in
  1)  IOC="$1" ;;
  2)  PHASE1_IN="$1"; IOC="$2" ;;
  3)  PHASE1_IN="$1"; IOC="$2"; OUT_BASE="$3" ;;
  *)  echo "Usage:"
      echo "  sudo /bin/bash $0 /tmp/mac_extract_YYYYmmdd_HHMMSS \"ioc-string\" [OUT_BASE_DIR]"
      echo "  sudo /bin/bash $0 \"ioc-string\" [OUT_BASE_DIR]"
      exit 1 ;;
esac
[[ -n "$IOC" ]] || err "Provide an IOC to search."

# -------------------- Resolve Phase-1 directory --------------------
is_dir(){ [[ -d "${1:-}" ]]; }
is_tgz(){ [[ "${1:-}" == *.tgz ]]; }

PHASE1_DIR=""; WORK_TMP=""
if [[ -n "$PHASE1_IN" ]]; then
  if is_dir "$PHASE1_IN"; then
    PHASE1_DIR="$PHASE1_IN"
  elif is_tgz "$PHASE1_IN"; then
    WORK_TMP="$(mktemp -d /tmp/_phase2_extract_XXXXXX)"
    echo "[*] Extracting tarball: $PHASE1_IN -> $WORK_TMP"
    tar -xzf "$PHASE1_IN" -C "$WORK_TMP"
    PHASE1_DIR="$(find "$WORK_TMP" -maxdepth 1 -type d -name 'mac_extract_*' -print -quit)"
    [[ -n "$PHASE1_DIR" ]] || err "Could not find extracted mac_extract_* folder in $WORK_TMP"
  else
    err "Given path is neither a folder nor a .tgz: $PHASE1_IN"
  fi
else
  PHASE1_DIR="$(find /tmp -maxdepth 1 -type d -name 'mac_extract_*' -print0 | xargs -0 ls -td 2>/dev/null | head -1 || true)"
  [[ -n "$PHASE1_DIR" ]] || err "No mac_extract_* folder found in /tmp. Provide the Phase-1 folder explicitly."
fi
[[ -d "$PHASE1_DIR" ]] || err "Phase-1 folder not found: $PHASE1_DIR"

# -------------------- Output directory logic --------------------
TS="$(date +%Y%m%d_%H%M%S)"

# Save Phase 2 results INSIDE the Phase 1 extraction folder
OUT_DIR="$PHASE1_DIR/phase2_results_${TS}"

mkdir -p "$OUT_DIR/hits"

echo "[*] Results directory  : $OUT_DIR"


IOC_DISP="$IOC"
echo "[*] Using Phase-1 folder: $PHASE1_DIR"
echo "[*] Searching for IOC  : $IOC_DISP"
echo "[*] Results directory  : $OUT_DIR"

# -------------------- Helpers --------------------
add_tl(){ # time_iso  source  evidence  filepath
  printf "%s\t%s\t%s\t%s\n" "$1" "$2" "$3" "$4" >> "$OUT_DIR/timeline.tsv"
}
echo -e "time_iso\tsource\tevidence\tfilepath" > "$OUT_DIR/timeline.tsv"

gri(){ # grep recursive insensitive
  grep -Rni -- "$IOC" "$1" 2>/dev/null || true
}

# -------------------- 1) Quarantine --------------------
echo "[*] Quarantine..."
if [[ -d "$PHASE1_DIR/Quarantine" ]]; then
  gri "$PHASE1_DIR/Quarantine" | tee "$OUT_DIR/hits/quarantine_hits.txt" >/dev/null
  if [[ -s "$OUT_DIR/hits/quarantine_hits.txt" ]]; then
    while IFS= read -r line; do
      add_tl "" "quarantine" "$line" "$PHASE1_DIR/Quarantine"
    done < "$OUT_DIR/hits/quarantine_hits.txt"
  fi
fi

# -------------------- 2) Chrome (Default) --------------------
echo "[*] Chrome (Default)..."
CHROME="$PHASE1_DIR/Chrome_Default"
if [[ -d "$CHROME" ]]; then
  [[ -f "$CHROME/URLs.csv" ]]      && gri "$CHROME/URLs.csv"      | tee "$OUT_DIR/hits/chrome_urls_hits.txt" >/dev/null
  [[ -f "$CHROME/Downloads.csv" ]] && gri "$CHROME/Downloads.csv" | tee "$OUT_DIR/hits/chrome_downloads_hits.txt" >/dev/null

  if [[ -f "$CHROME/URLs.csv" ]]; then
    awk -F, -v IGNORECASE=1 -v ioc="$IOC" 'NR>1 && $0~ioc {gsub(/"/,"",$2); print $2"\tchrome_urls\tvisit "$1"\tF:URLs.csv"}' \
      "$CHROME/URLs.csv" >> "$OUT_DIR/timeline.tsv" 2>/dev/null || true
  fi
  if [[ -f "$CHROME/Downloads.csv" ]]; then
    awk -F, -v IGNORECASE=1 -v ioc="$IOC" 'NR>1 && $0~ioc {gsub(/"/,"",$5); print $5"\tchrome_downloads\tdownload target="$1" tab="$3" danger="$4"\tF:Downloads.csv"}' \
      "$CHROME/Downloads.csv" >> "$OUT_DIR/timeline.tsv" 2>/dev/null || true
  fi
fi

# -------------------- 3) Safari --------------------
echo "[*] Safari..."
SAF="$PHASE1_DIR/Safari"
if [[ -d "$SAF" ]]; then
  gri "$SAF" | tee "$OUT_DIR/hits/safari_hits.txt" >/dev/null
  if [[ -f "$SAF/Safari_History.csv" ]]; then
    awk -F, -v IGNORECASE=1 -v ioc="$IOC" 'NR>1 && $0~ioc {gsub(/"/,"",$2); print $2"\tsafari_history\tvisit "$1"\tF:Safari_History.csv"}' \
      "$SAF/Safari_History.csv" >> "$OUT_DIR/timeline.tsv" 2>/dev/null || true
  fi
fi

# -------------------- 4) Firefox --------------------
echo "[*] Firefox..."
FF="$PHASE1_DIR/Firefox"
if [[ -d "$FF" ]]; then
  find "$FF" -type f -name "places.csv" -print0 2>/dev/null | while IFS= read -r -d '' f; do
    gri "$f" | tee -a "$OUT_DIR/hits/firefox_hits.txt" >/dev/null
    awk -F, -v IGNORECASE=1 -v ioc="$IOC" 'NR>1 && $0~ioc {gsub(/"/,"",$2); print $2"\tfirefox_history\tvisit "$1"\tF:'"$f"'"}' \
      "$f" >> "$OUT_DIR/timeline.tsv" 2>/dev/null || true
  done
fi

# -------------------- 5) Downloads metadata --------------------
echo "[*] Downloads metadata..."
DMD="$PHASE1_DIR/Downloads"
if [[ -d "$DMD" ]]; then
  gri "$DMD" | tee "$OUT_DIR/hits/downloads_metadata_hits.txt" >/dev/null
fi

# -------------------- 6) Unified Logs (general + DNS + TLS) --------------------
echo "[*] Unified Logs..."
UARCH="$(find "$PHASE1_DIR/UnifiedLogs" -maxdepth 1 -type d -name '*.logarchive' -print -quit 2>/dev/null || true)"
if [[ -n "${UARCH:-}" ]] && has_cmd log; then
  log show --archive "$UARCH" --info --predicate "eventMessage CONTAINS[c] \"$IOC\"" --style syslog \
    > "$OUT_DIR/hits/unified_general.txt" 2>/dev/null || true
  log show --archive "$UARCH" --info --predicate 'process == "mDNSResponder" AND eventMessage CONTAINS[c] "'"$IOC"'"' --style syslog \
    > "$OUT_DIR/hits/unified_dns.txt" 2>/dev/null || true
  log show --archive "$UARCH" --info --predicate 'process == "trustd" AND eventMessage CONTAINS[c] "'"$IOC"'"' --style syslog \
    > "$OUT_DIR/hits/unified_tls.txt" 2>/dev/null || true

  for f in unified_general.txt unified_dns.txt unified_tls.txt; do
    [[ -s "$OUT_DIR/hits/$f" ]] || continue
    awk '
      BEGIN{FS="[[:space:]]+"}
      /^[0-9]{4}-[0-9]{2}-[0-9]{2}/{
        ts=$1" "$2; sub(/\..*/,"",ts);  # trim fractional seconds
        print ts "\t" "'"${f%.txt}"'" "\t" $0 "\t" "'"$UARCH"'"
      }' "$OUT_DIR/hits/$f" >> "$OUT_DIR/timeline.tsv" || true
  done
else
  echo "[*] No .logarchive found or 'log' tool unavailable; skipping." | tee -a "$OUT_DIR/notes.txt"
fi

# -------------------- 7) Execution Forensics (process launches) --------------------
echo "[*] Execution artifacts..."

EXEC_OUT="$OUT_DIR/hits/unified_exec.txt"

if [[ -n "${UARCH:-}" ]] && has_cmd log; then

  # 1. Direct matches: process name contains IOC
  log show --archive "$UARCH" --info \
    --predicate "process CONTAINS[c] \"$IOC\"" --style syslog \
    > "$EXEC_OUT" 2>/dev/null || true

  # 2. Kernel exec events
  log show --archive "$UARCH" --info \
    --predicate 'eventMessage CONTAINS[c] "exec" AND eventMessage CONTAINS[c] "'"$IOC"'"' --style syslog \
    >> "$EXEC_OUT" 2>/dev/null || true

  # 3. Gatekeeper / code signing / trustd
  log show --archive "$UARCH" --info \
    --predicate 'process == "trustd" AND eventMessage CONTAINS[c] "'"$IOC"'"' --style syslog \
    >> "$EXEC_OUT" 2>/dev/null || true

  # 4. Launch services (UI app openings)
  log show --archive "$UARCH" --info \
    --predicate 'process == "launchservicesd" AND eventMessage CONTAINS[c] "'"$IOC"'"' --style syslog \
    >> "$EXEC_OUT" 2>/dev/null || true

  # Append execution events into timeline
  if [[ -s "$EXEC_OUT" ]]; then
    awk '
      BEGIN{FS="[[:space:]]+"}
      /^[0-9]{4}-[0-9]{2}-[0-9]{2}/{
        ts=$1" "$2; sub(/\..*/, "", ts);
        print ts "\texec\t" $0 "\tUnifiedLogs" 
      }' "$EXEC_OUT" >> "$OUT_DIR/timeline.tsv"
  fi

else
  echo "[*] Unified logs unavailable; skipping execution search." | tee -a "$OUT_DIR/notes.txt"
fi

# -------------------- 8) Sort timeline & write summary/report --------------------
{ read -r header; echo "$header"; sort -k1,1 -k2,2; } < "$OUT_DIR/timeline.tsv" > "$OUT_DIR/timeline.sorted.tsv" || true
mv "$OUT_DIR/timeline.sorted.tsv" "$OUT_DIR/timeline.tsv" || true

# Safe summary (no printf warnings)
{
  echo "IOC: $IOC_DISP"
  echo "Phase-1 folder: $PHASE1_DIR"
  echo ""
  for f in "$OUT_DIR"/hits/*.txt; do
    [[ -e "$f" ]] || continue
    # grep -ic may return empty on error; coerce to 0 safely
    n="$(grep -ic -- "$IOC" "$f" 2>/dev/null || true)"
    [[ "$n" =~ ^[0-9]+$ ]] || n=0
    printf "%-24s : %s\n" "$(basename "$f")" "$n"
  done
} | tee "$OUT_DIR/summary.txt"

# Simple markdown report
{
  echo "# mac_extract_phase2 report"
  echo ""
  echo "**IOC:** \`$IOC_DISP\`  "
  echo "**Phase-1 folder:** \`$PHASE1_DIR\`  "
  echo ""
  echo "## Summary"
  echo '```'
  cat "$OUT_DIR/summary.txt"
  echo '```'
  echo ""
  echo "## Timeline (first 100 rows)"
  echo '```tsv'
  head -n 101 "$OUT_DIR/timeline.tsv"
  echo '```'
  echo ""
  echo "## Raw hit files"
  for f in "$OUT_DIR"/hits/*.txt; do
    echo "- $(basename "$f")"
  done
} > "$OUT_DIR/report.md"

echo ""
echo "=== DONE ==="
echo "Summary : $OUT_DIR/summary.txt"
echo "Timeline: $OUT_DIR/timeline.tsv"
echo "Report  : $OUT_DIR/report.md"
echo "Hits    : $OUT_DIR/hits/"
[[ -n "${WORK_TMP:-}" ]] && rm -rf "$WORK_TMP" || true
