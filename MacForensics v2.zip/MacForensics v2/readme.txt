This version 
-Saves output to .csv's 
-Removes scareware search