#!/usr/bin/env bash
# mac_extract_phase1.sh
# Phase 1 extractor for macOS phishing investigations
# - Copies raw artifacts (history DBs, Quarantine DB, etc.)
# - Emits SQLite .dump.sql (lossless) and CSV normalizations (IOC-agnostic)
# - Preserves Unified Logs as a .logarchive for the last 7 days (sudo mode)
# Output: /tmp/mac_extract_<timestamp>/ + tarball path

set -euo pipefail

has_cmd(){ command -v "$1" >/dev/null 2>&1; }

# Heuristic check for Full Disk Access (FDA) for Terminal
check_full_disk_access() {
  local probe="$HOME/Library/Mail"
  if [ -d "$probe" ]; then
    # Try to list; if "Operation not permitted" appears, FDA is likely missing
    if ! ls "$probe" >/dev/null 2>&1; then
      if ls "$probe" 2>&1 | grep -qi "Operation not permitted"; then
        echo "[!] WARNING: Terminal may not have Full Disk Access."
        echo "[!] Some protected artifacts (Safari history, Mail, etc.) may be incomplete."
        echo "[!] To fix: System Settings → Privacy & Security → Full Disk Access → enable for Terminal."
      fi
    fi
  fi
}

# JSON-escape without legacy 'python' shim
json_escape() {
  if [ -x /usr/bin/python3 ]; then
    /usr/bin/python3 - <<'PY' "$1"
import json, sys
print(json.dumps(sys.argv[1]))
PY
  else
    # Basic fallback (good enough for paths in manifest)
    printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g'
  fi
}

sha256_file(){
  local f="$1"
  if has_cmd shasum; then
    shasum -a 256 "$f" 2>/dev/null | awk '{print $1}'
  elif has_cmd openssl; then
    openssl dgst -sha256 "$f" 2>/dev/null | awk '{print $2}'
  else
    echo ""
  fi
}

safe_cp(){
  local src="$1" dst="$2"
  [ -e "$src" ] || return 0
  mkdir -p "$(dirname "$dst")"
  cp -a "$src" "$dst" 2>/dev/null || rsync -aH "$src" "$dst" 2>/dev/null || true
}

add_manifest_entry(){
  local path="$1" kind="$2"
  [ -e "$path" ] || return 0
  local rel="${path#$OUT/}"
  local size="$(/usr/bin/stat -f %z "$path" 2>/dev/null || echo 0)"
  local sha="$(sha256_file "$path")"
  printf '{ "path": %s, "kind": %s, "size": %s, "sha256": %s }' \
    "$(json_escape "$rel")" "$(json_escape "$kind")" "$size" "$(json_escape "$sha")"
}

append_manifest(){
  local path="$1" kind="$2"
  local entry
  entry="$(add_manifest_entry "$path" "$kind")" || true
  [ -n "${entry:-}" ] && echo "  ${entry}," >> "$OUT/_manifest_items.tmp"
}

# ---------- params / modes ----------
NO_SUDO=0
RANGE="7d"   # fixed: always collect last 7 days of unified logs (when sudo is available)

# Parse args: optional --no-sudo only
while [[ $# -gt 0 ]]; do
  case "$1" in
    --no-sudo)
      NO_SUDO=1
      shift
      ;;
    *)
      echo "[-] Unknown argument: $1" >&2
      echo "Usage: $0 [--no-sudo]" >&2
      exit 1
      ;;
  esac
done

# sudo banner / auto-fallback
if [[ $EUID -ne 0 && $NO_SUDO -eq 0 ]]; then
  echo "[!] WARNING: mac_extract_phase1.sh is NOT running as root."
  echo "[!] Some artifacts require sudo (Unified Logs, system quarantine DB, system persistence)."
  echo "[!] For FULL collection, re-run with:"
  echo "    sudo $0"
  echo "[*] Automatically enabling --no-sudo fallback mode for this run."
  NO_SUDO=1
fi

# Always show a note if running in no-sudo mode (whether explicit or automatic)
if [[ $NO_SUDO -eq 1 ]]; then
  echo "[*] NOTE: Running in NO-SUDO mode."
  echo "[*] Unified Logs and some system-level artifacts will be skipped."
fi

check_full_disk_access

# ---------- output root ----------
TS="$(date +%Y%m%d_%H%M%S)"
OUT="/tmp/mac_extract_${TS}"
mkdir -p "$OUT"
echo "[*] Output: $OUT"

# ---------- manifest header ----------
HOSTNAME="$(hostname || true)"
OSVERS="$(sw_vers 2>/dev/null | tr '\n' ' ' || true)"
WHO="$(id -un 2>/dev/null || echo unknown)"
START_ISO="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
echo "[" > "$OUT/_manifest_items.tmp"

# ---------- host info ----------
{
  echo "timestamp_utc: $START_ISO"
  uname -a
  sw_vers 2>/dev/null || true
  id
  echo "hostname: $HOSTNAME"
  date -u
} > "$OUT/host_info.txt"
append_manifest "$OUT/host_info.txt" "text"

# ---------- Downloads snapshot ----------
echo "[*] Snapshot: ~/Downloads"
mkdir -p "$OUT/Downloads"
(ls -laT ~/Downloads || true) > "$OUT/Downloads/listing.txt" 2>/dev/null || true
append_manifest "$OUT/Downloads/listing.txt" "text"

/usr/bin/stat -f "file:%N\nsize:%z\nmtime:%Sm\nctime:%Sc\natime:%Sa\n" ~/Downloads/* 2>/dev/null \
  > "$OUT/Downloads/stat.txt" || true
append_manifest "$OUT/Downloads/stat.txt" "text"

{
  for f in ~/Downloads/*; do
    [ -e "$f" ] || continue
    echo "---- $f ----"
    xattr -l "$f" 2>/dev/null || true
  done
} > "$OUT/Downloads/xattrs.txt"
append_manifest "$OUT/Downloads/xattrs.txt" "text"

{
  for f in ~/Downloads/*; do
    [ -e "$f" ] || continue
    echo "---- $f ----"
    mdls "$f" 2>/dev/null || true
  done
} > "$OUT/Downloads/mdls.txt"
append_manifest "$OUT/Downloads/mdls.txt" "text"

if has_cmd shasum; then
  (shasum -a 256 ~/Downloads/* 2>/dev/null || true) > "$OUT/Downloads/sha256.txt" || true
  append_manifest "$OUT/Downloads/sha256.txt" "text"
fi

# ---------- Quarantine DB (user + optional system) ----------
echo "[*] Quarantine DB"
QUAR_PATHS=("$HOME/Library/Preferences/com.apple.LaunchServices.QuarantineEventsV2")
if [[ $NO_SUDO -eq 0 ]]; then
  QUAR_PATHS+=("/var/db/lsd/com.apple.LaunchServices.QuarantineEventsV2")
fi

for Q in "${QUAR_PATHS[@]}"; do
  if [ -f "$Q" ]; then
    base="$(basename "$Q")"
    dst="$OUT/Quarantine/$base"
    safe_cp "$Q" "$dst"
    append_manifest "$dst" "db"
    if has_cmd sqlite3; then
      sqlite3 "$dst" .dump > "$dst.dump.sql" 2>/dev/null || true
      append_manifest "$dst.dump.sql" "sql_dump"
      sqlite3 "$dst" "SELECT name FROM sqlite_master WHERE type='table' AND name LIKE 'LSQuarantine%';" \
        | while read -r t; do
            [ -z "$t" ] && continue
            sqlite3 -csv "$dst" "SELECT * FROM $t;" > "$dst.${t}.csv" 2>/dev/null || true
            append_manifest "$dst.${t}.csv" "csv"
          done
    fi
  fi
done

# ---------- Safari ----------
echo "[*] Safari"
mkdir -p "$OUT/Safari"
SAFE_SAFARI_DB="$OUT/Safari/Safari_History.db"
safe_cp "$HOME/Library/Safari/History.db" "$SAFE_SAFARI_DB"
[ -f "$SAFE_SAFARI_DB" ] && append_manifest "$SAFE_SAFARI_DB" "db"

if [ -f "$SAFE_SAFARI_DB" ] && has_cmd sqlite3; then
  sqlite3 "$SAFE_SAFARI_DB" .dump > "$OUT/Safari/Safari_History.dump.sql" 2>/dev/null || true
  append_manifest "$OUT/Safari/Safari_History.dump.sql" "sql_dump"
  sqlite3 -csv "$SAFE_SAFARI_DB" \
   "SELECT history_items.url,
           datetime(history_visits.visit_time + 978307200,'unixepoch') AS visit_time_iso,
           history_visits.title
    FROM history_items
    JOIN history_visits ON history_items.id = history_visits.history_item;" \
    > "$OUT/Safari/Safari_History.csv" 2>/dev/null || true
  append_manifest "$OUT/Safari/Safari_History.csv" "csv"
fi

if [ -f "$HOME/Library/Safari/Downloads.plist" ]; then
  plutil -convert xml1 -o "$OUT/Safari/Safari_Downloads.plist.xml" "$HOME/Library/Safari/Downloads.plist" 2>/dev/null || true
  [ -f "$OUT/Safari/Safari_Downloads.plist.xml" ] && append_manifest "$OUT/Safari/Safari_Downloads.plist.xml" "xml"
fi

safe_cp "$HOME/Library/Safari/LocalStorage" "$OUT/Safari/LocalStorage"
[ -e "$OUT/Safari/LocalStorage" ] && append_manifest "$OUT/Safari/LocalStorage" "dir"

# ---------- Chrome (Default profile) ----------
echo "[*] Chrome (Default profile)"
CHROME_DEFAULT="$HOME/Library/Application Support/Google/Chrome/Default"
if [ -d "$CHROME_DEFAULT" ]; then
  mkdir -p "$OUT/Chrome_Default"
  if [ -f "$CHROME_DEFAULT/History" ]; then
    safe_cp "$CHROME_DEFAULT/History" "$OUT/Chrome_Default/History"
    append_manifest "$OUT/Chrome_Default/History" "db"
    if has_cmd sqlite3; then
      sqlite3 "$OUT/Chrome_Default/History" .dump > "$OUT/Chrome_Default/History.dump.sql" 2>/dev/null || true
      append_manifest "$OUT/Chrome_Default/History.dump.sql" "sql_dump"
      sqlite3 -csv "$OUT/Chrome_Default/History" \
       "SELECT url,
               datetime(last_visit_time/1000000-11644473600,'unixepoch') AS last_visit_time_iso,
               title
        FROM urls;" > "$OUT/Chrome_Default/URLs.csv" 2>/dev/null || true
      append_manifest "$OUT/Chrome_Default/URLs.csv" "csv"
      sqlite3 -csv "$OUT/Chrome_Default/History" \
       "SELECT target_path,
               current_path,
               tab_url,
               danger_type,
               datetime(start_time/1000000-11644473600,'unixepoch') AS start_time_iso
        FROM downloads;" > "$OUT/Chrome_Default/Downloads.csv" 2>/dev/null || true
      append_manifest "$OUT/Chrome_Default/Downloads.csv" "csv"
    fi
  fi
  safe_cp "$CHROME_DEFAULT/Cookies" "$OUT/Chrome_Default/Cookies"
  [ -f "$OUT/Chrome_Default/Cookies" ] && append_manifest "$OUT/Chrome_Default/Cookies" "db_encrypted"
  safe_cp "$CHROME_DEFAULT/Preferences" "$OUT/Chrome_Default/Preferences.json"
  [ -f "$OUT/Chrome_Default/Preferences.json" ] && append_manifest "$OUT/Chrome_Default/Preferences.json" "json"
  safe_cp "$CHROME_DEFAULT/Service Worker/CacheStorage" "$OUT/Chrome_Default/ServiceWorker_Cache" || true
  [ -e "$OUT/Chrome_Default/ServiceWorker_Cache" ] && append_manifest "$OUT/Chrome_Default/ServiceWorker_Cache" "dir"
fi

# ---------- Edge (Default profile) ----------
echo "[*] Edge (Default profile)"
EDGE_DEFAULT="$HOME/Library/Application Support/Microsoft Edge/Default"
if [ -d "$EDGE_DEFAULT" ]; then
  mkdir -p "$OUT/Edge_Default"

  # Edge History -> copy + dump + CSV (same Chromium schema as Chrome)
  if [ -f "$EDGE_DEFAULT/History" ]; then
    safe_cp "$EDGE_DEFAULT/History" "$OUT/Edge_Default/History"
    append_manifest "$OUT/Edge_Default/History" "db"

    if has_cmd sqlite3; then
      # Full SQL dump (lossless)
      sqlite3 "$OUT/Edge_Default/History" .dump > "$OUT/Edge_Default/History.dump.sql" 2>/dev/null || true
      append_manifest "$OUT/Edge_Default/History.dump.sql" "sql_dump"

      # URLs table -> CSV
      sqlite3 -csv "$OUT/Edge_Default/History" \
       "SELECT url,
               datetime(last_visit_time/1000000-11644473600,'unixepoch') AS last_visit_time_iso,
               title
        FROM urls;" > "$OUT/Edge_Default/URLs.csv" 2>/dev/null || true
      append_manifest "$OUT/Edge_Default/URLs.csv" "csv"

      # Downloads table -> CSV
      sqlite3 -csv "$OUT/Edge_Default/History" \
       "SELECT target_path,
               current_path,
               tab_url,
               danger_type,
               datetime(start_time/1000000-11644473600,'unixepoch') AS start_time_iso
        FROM downloads;" > "$OUT/Edge_Default/Downloads.csv" 2>/dev/null || true
      append_manifest "$OUT/Edge_Default/Downloads.csv" "csv"
    fi
  fi

  # Edge cookies DB (encrypted) – still useful as a forensic artifact
  safe_cp "$EDGE_DEFAULT/Cookies" "$OUT/Edge_Default/Cookies"
  [ -f "$OUT/Edge_Default/Cookies" ] && append_manifest "$OUT/Edge_Default/Cookies" "db_encrypted"

  # Preferences JSON
  safe_cp "$EDGE_DEFAULT/Preferences" "$OUT/Edge_Default/Preferences.json"
  [ -f "$OUT/Edge_Default/Preferences.json" ] && append_manifest "$OUT/Edge_Default/Preferences.json" "json"

  # Service Worker cache
  safe_cp "$EDGE_DEFAULT/Service Worker/CacheStorage" "$OUT/Edge_Default/ServiceWorker_Cache" || true
  [ -e "$OUT/Edge_Default/ServiceWorker_Cache" ] && append_manifest "$OUT/Edge_Default/ServiceWorker_Cache" "dir"
fi

# ---------- Firefox (iterate common profiles) ----------
echo "[*] Firefox (profiles)"
FF_DIR="$HOME/Library/Application Support/Firefox/Profiles"
if [ -d "$FF_DIR" ]; then
  mkdir -p "$OUT/Firefox"
  for p in "$FF_DIR"/*.default* "$FF_DIR"/*.release* "$FF_DIR"/*.esr*; do
    [ -d "$p" ] || continue
    b="$(basename "$p")"
    pf_out="$OUT/Firefox/$b"
    mkdir -p "$pf_out"
    if [ -f "$p/places.sqlite" ]; then
      safe_cp "$p/places.sqlite" "$pf_out/places.sqlite"
      append_manifest "$pf_out/places.sqlite" "db"
      if has_cmd sqlite3; then
        sqlite3 "$pf_out/places.sqlite" .dump > "$pf_out/places.dump.sql" 2>/dev/null || true
        append_manifest "$pf_out/places.dump.sql" "sql_dump"
        sqlite3 -csv "$pf_out/places.sqlite" \
          "SELECT url,
                  datetime(last_visit_date/1000000,'unixepoch') AS last_visit_time_iso
           FROM moz_places;" > "$pf_out/places.csv" 2>/dev/null || true
        append_manifest "$pf_out/places.csv" "csv"
      fi
    fi
    safe_cp "$p/cookies.sqlite" "$pf_out/cookies.sqlite"
    [ -f "$pf_out/cookies.sqlite" ] && append_manifest "$pf_out/cookies.sqlite" "db"
    safe_cp "$p/storage" "$pf_out/storage"
    [ -e "$pf_out/storage" ] && append_manifest "$pf_out/storage" "dir"
    safe_cp "$p/cache2" "$pf_out/cache2"
    [ -e "$pf_out/cache2" ] && append_manifest "$pf_out/cache2" "dir"
  done
fi

# ---------- Unified logs (preserve only) ----------
if [[ $NO_SUDO -eq 1 ]]; then
  echo "[*] Unified logs archive skipped (no-sudo mode)."
else
  echo "[*] Unified logs archive (preserve last $RANGE)"
  mkdir -p "$OUT/UnifiedLogs"
  ARCHIVE="$OUT/UnifiedLogs/unified_${RANGE}.logarchive"
  log collect --last "$RANGE" --output "$ARCHIVE" 2>/dev/null || true
  [ -e "$ARCHIVE" ] && append_manifest "$ARCHIVE" "logarchive"
fi

# ---------- Network snapshot ----------
echo "[*] Network snapshot"
(scutil --dns || true) > "$OUT/scutil_dns.txt" 2>/dev/null || true
append_manifest "$OUT/scutil_dns.txt" "text"
(networksetup -listallhardwareports || true) > "$OUT/network_hwports.txt" 2>/dev/null || true
append_manifest "$OUT/network_hwports.txt" "text"

# ---------- Persistence listings ----------
echo "[*] Persistence listings"
{
  for d in "$HOME/Library/LaunchAgents" /Library/LaunchAgents /Library/LaunchDaemons /Library/StartupItems; do
    [ -d "$d" ] || continue
    echo "## $d"
    ls -laT "$d" 2>/dev/null || echo "(permission denied)"
    echo
  done
} > "$OUT/persistence_listing.txt"
append_manifest "$OUT/persistence_listing.txt" "text"

# ---------- finalize manifest ----------
END_ISO="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
sed -i '' -e '$ s/,$//' "$OUT/_manifest_items.tmp" 2>/dev/null || true
{
  echo "{"
  echo "  \"tool\": \"mac_extract_phase1\","
  echo "  \"version\": \"1.2.1-fixed7d\","
  echo "  \"host\": $(json_escape "$HOSTNAME"),"
  echo "  \"user\": $(json_escape "$WHO"),"
  echo "  \"os\": $(json_escape "$OSVERS"),"
  echo "  \"started_utc\": $(json_escape "$START_ISO"),"
  echo "  \"ended_utc\": $(json_escape "$END_ISO"),"
  echo "  \"unified_logs_range\": $(json_escape "$RANGE"),"
  echo "  \"no_sudo_mode\": $(json_escape "$NO_SUDO"),"
  echo "  \"items\": "
  cat "$OUT/_manifest_items.tmp"
  echo "}"
} > "$OUT/manifest.json"
rm -f "$OUT/_manifest_items.tmp"
append_manifest "$OUT/manifest.json" "json" || true

# ---------- package ----------
TARBALL="/tmp/mac_extract_${TS}.tgz"
tar -czf "$TARBALL" -C "/tmp" "mac_extract_${TS}"

echo ""
echo "=== COMPLETE ==="
echo "Folder : $OUT"
echo "Tarball: $TARBALL"
echo ""
echo "Tip: run with sudo AND Full Disk Access for Terminal so protected files are fully readable."
echo ""
echo "Next steps – Phase 2 correlation (mac_extract_phase2.sh):"
echo "Adjust commands if running in sudo mode"
echo "  # IOC search (domain, URL fragment, filename, etc.) against THIS Phase-1 folder"
echo "  /bin/bash mac_extract_phase2.sh \"$OUT\" \"example.com\""
echo ""
echo "  # IOC search using the most recent /tmp/mac_extract_* folder automatically"
echo "  /bin/bash mac_extract_phase2.sh \"example.com\""
echo ""
echo "  # Scareware mode (built-in scareware rules) on THIS Phase-1 folder"
echo "  /bin/bash mac_extract_phase2.sh \"$OUT\" --scareware"
echo ""
echo "  # Scareware mode with time filter (time filter currently applies only to scareware mode)"
echo "  /bin/bash mac_extract_phase2.sh \"$OUT\" --scareware -d 2    # last 2 days"
echo "  /bin/bash mac_extract_phase2.sh \"$OUT\" --scareware -t 90m  # last 90 minutes"
echo "  /bin/bash mac_extract_phase2.sh \"$OUT\" --scareware -t 1h   # last 1 hour"
echo ""
echo "mac_extract_phase2.sh will write hits/, summary.txt, timeline.tsv, and report.md inside the Phase-1 folder."
