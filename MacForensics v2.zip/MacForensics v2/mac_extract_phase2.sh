#!/usr/bin/env bash
# mac_extract_phase2.sh — Search & correlate IOCs in a Phase 1 mac_extract_* collection
#
# Usage:
#   /bin/bash mac_extract_phase2.sh /tmp/mac_extract_YYYYmmdd_HHMMSS "chatgpt.com"
#   /bin/bash mac_extract_phase2.sh "chatgpt.com"          # auto-detect latest /tmp/mac_extract_*
#
# Output:
#   <Phase1>/phase2_results_<ts>/
#     ├─ hits/*.csv
#     ├─ timeline.tsv
#     ├─ summary.txt
#     └─ report.md

set -euo pipefail

has_cmd(){ command -v "$1" >/dev/null 2>&1; }
err(){ echo "[-] $*" >&2; exit 1; }

is_dir(){ [[ -d "${1:-}" ]]; }
is_tgz(){ [[ "${1:-}" == *.tgz ]]; }

# -------------------- Parse args (IOC-only) --------------------
PHASE1_IN=""
IOC=""

if [[ $# -eq 0 ]]; then
  echo "Usage:"
  echo "  /bin/bash $0 /tmp/mac_extract_YYYYmmdd_HHMMSS \"ioc-string\""
  echo "  /bin/bash $0 \"ioc-string\""
  exit 1
fi

while [[ $# -gt 0 ]]; do
  case "$1" in
    *)
      if [[ -z "$PHASE1_IN" && ( "$1" == /tmp/mac_extract_* || "$1" == *.tgz ) ]]; then
        PHASE1_IN="$1"
        shift
      elif [[ -z "$IOC" ]]; then
        IOC="$1"
        shift
      else
        err "Unexpected argument: $1"
      fi
      ;;
  esac
done

[[ -n "${IOC:-}" ]] || err "Provide an IOC (e.g. domain, filename)."

# -------------------- Resolve Phase-1 directory --------------------
PHASE1_DIR=""
WORK_TMP=""

if [[ -n "$PHASE1_IN" ]]; then
  if is_dir "$PHASE1_IN"; then
    PHASE1_DIR="$PHASE1_IN"
  elif is_tgz "$PHASE1_IN"; then
    WORK_TMP="$(mktemp -d /tmp/_phase2_extract_XXXXXX)"
    echo "[*] Extracting tarball: $PHASE1_IN -> $WORK_TMP"
    tar -xzf "$PHASE1_IN" -C "$WORK_TMP"
    PHASE1_DIR="$(find "$WORK_TMP" -maxdepth 1 -type d -name 'mac_extract_*' -print -quit)"
    [[ -n "$PHASE1_DIR" ]] || err "Could not find extracted mac_extract_* folder in $WORK_TMP"
  else
    err "Given path is neither a folder nor a .tgz: $PHASE1_IN"
  fi
else
  PHASE1_DIR="$(find /tmp -maxdepth 1 -type d -name 'mac_extract_*' -print0 | xargs -0 ls -td 2>/dev/null | head -1 || true)"
  [[ -n "$PHASE1_DIR" ]] || err "No mac_extract_* folder found in /tmp. Provide the Phase-1 folder explicitly."
fi

[[ -d "$PHASE1_DIR" ]] || err "Phase-1 folder not found: $PHASE1_DIR"

TS="$(date +%Y%m%d_%H%M%S)"
OUT_DIR="$PHASE1_DIR/phase2_results_${TS}"
mkdir -p "$OUT_DIR/hits"

IOC_DISP="$IOC"
echo "[*] Results directory  : $OUT_DIR"
echo "[*] Using Phase-1 folder: $PHASE1_DIR"
echo "[*] Mode               : IOC"
echo "[*] Searching for      : $IOC_DISP"

# -------------------- Helpers --------------------
add_tl(){ # time_iso  source  evidence  filepath
  printf "%s\t%s\t%s\t%s\n" "$1" "$2" "$3" "$4" >> "$OUT_DIR/timeline.tsv"
}

echo -e "time_iso\tsource\tevidence\tfilepath" > "$OUT_DIR/timeline.tsv"

gri_ioc(){ grep -Rni -- "$IOC" "$1" 2>/dev/null || true; }

AWK_PATTERN="$IOC"

# -------------------- 1) Quarantine --------------------
echo "[*] Quarantine..."
if [[ -d "$PHASE1_DIR/Quarantine" ]]; then
  gri_ioc "$PHASE1_DIR/Quarantine" | tee "$OUT_DIR/hits/quarantine_hits.txt" >/dev/null
  if [[ -s "$OUT_DIR/hits/quarantine_hits.txt" ]]; then
    while IFS= read -r line; do
      add_tl "" "quarantine" "$line" "$PHASE1_DIR/Quarantine"
    done < "$OUT_DIR/hits/quarantine_hits.txt"
  fi
fi

# -------------------- 2) Chrome (Default) --------------------
echo "[*] Chrome (Default)..."
CHROME="$PHASE1_DIR/Chrome_Default"
if [[ -d "$CHROME" ]]; then
  [[ -f "$CHROME/URLs.csv" ]]      && gri_ioc "$CHROME/URLs.csv"      | tee "$OUT_DIR/hits/chrome_urls_hits.txt" >/dev/null
  [[ -f "$CHROME/Downloads.csv" ]] && gri_ioc "$CHROME/Downloads.csv" | tee "$OUT_DIR/hits/chrome_downloads_hits.txt" >/dev/null

  if [[ -f "$CHROME/URLs.csv" ]]; then
    awk -F, -v IGNORECASE=1 -v pattern="$AWK_PATTERN" \
      'NR>1 && $0 ~ pattern {
         gsub(/"/,"",$2);
         print $2 "\tchrome_urls\tvisit " $1 "\tF:Chrome_Default/URLs.csv"
       }' \
      "$CHROME/URLs.csv" >> "$OUT_DIR/timeline.tsv" 2>/dev/null || true
  fi

  if [[ -f "$CHROME/Downloads.csv" ]]; then
    awk -F, -v IGNORECASE=1 -v pattern="$AWK_PATTERN" \
      'NR>1 && $0 ~ pattern {
         gsub(/"/,"",$5);
         print $5 "\tchrome_downloads\tdownload target=" $1 " tab=" $3 " danger=" $4 "\tF:Chrome_Default/Downloads.csv"
       }' \
      "$CHROME/Downloads.csv" >> "$OUT_DIR/timeline.tsv" 2>/dev/null || true
  fi
fi

# -------------------- 2b) Edge (Default) --------------------
echo "[*] Edge (Default)..."
EDGE="$PHASE1_DIR/Edge_Default"
if [[ -d "$EDGE" ]]; then
  [[ -f "$EDGE/URLs.csv" ]]      && gri_ioc "$EDGE/URLs.csv"      | tee "$OUT_DIR/hits/edge_urls_hits.txt" >/dev/null
  [[ -f "$EDGE/Downloads.csv" ]] && gri_ioc "$EDGE/Downloads.csv" | tee "$OUT_DIR/hits/edge_downloads_hits.txt" >/dev/null

  if [[ -f "$EDGE/URLs.csv" ]]; then
    awk -F, -v IGNORECASE=1 -v pattern="$AWK_PATTERN" \
      'NR>1 && $0 ~ pattern {
         gsub(/"/,"",$2);
         print $2 "\tedge_urls\tvisit " $1 "\tF:Edge_Default/URLs.csv"
       }' \
      "$EDGE/URLs.csv" >> "$OUT_DIR/timeline.tsv" 2>/dev/null || true
  fi

  if [[ -f "$EDGE/Downloads.csv" ]]; then
    awk -F, -v IGNORECASE=1 -v pattern="$AWK_PATTERN" \
      'NR>1 && $0 ~ pattern {
         gsub(/"/,"",$5);
         print $5 "\tedge_downloads\tdownload target=" $1 " tab=" $3 " danger=" $4 "\tF:Edge_Default/Downloads.csv"
       }' \
      "$EDGE/Downloads.csv" >> "$OUT_DIR/timeline.tsv" 2>/dev/null || true
  fi
fi

# -------------------- 3) Safari --------------------
echo "[*] Safari..."
SAF="$PHASE1_DIR/Safari"
if [[ -d "$SAF" ]]; then
  gri_ioc "$SAF" | tee "$OUT_DIR/hits/safari_hits.txt" >/dev/null

  if [[ -f "$SAF/Safari_History.csv" ]]; then
    awk -F, -v IGNORECASE=1 -v pattern="$AWK_PATTERN" \
      'NR>1 && $0 ~ pattern {
         gsub(/"/,"",$2);
         print $2 "\tsafari_history\tvisit " $1 "\tF:Safari/Safari_History.csv"
       }' \
      "$SAF/Safari_History.csv" >> "$OUT_DIR/timeline.tsv" 2>/dev/null || true
  fi
fi

# -------------------- 4) Firefox --------------------
echo "[*] Firefox..."
FF="$PHASE1_DIR/Firefox"
if [[ -d "$FF" ]]; then
  find "$FF" -type f -name "places.csv" -print0 2>/dev/null | while IFS= read -r -d '' f; do
    gri_ioc "$f" | tee -a "$OUT_DIR/hits/firefox_hits.txt" >/dev/null

    awk -F, -v IGNORECASE=1 -v pattern="$AWK_PATTERN" \
      'NR>1 && $0 ~ pattern {
         gsub(/"/,"",$2);
         print $2 "\tfirefox_history\tvisit " $1 "\tF:'"$f"'"
       }' \
      "$f" >> "$OUT_DIR/timeline.tsv" 2>/dev/null || true
  done
fi

# -------------------- 5) Downloads metadata --------------------
echo "[*] Downloads metadata..."
DMD="$PHASE1_DIR/Downloads"
if [[ -d "$DMD" ]]; then
  gri_ioc "$DMD" | tee "$OUT_DIR/hits/downloads_metadata_hits.txt" >/dev/null
fi

# -------------------- 6) Unified Logs --------------------
echo "[*] Unified Logs..."
UARCH="$(find "$PHASE1_DIR/UnifiedLogs" -maxdepth 1 -type d -name '*.logarchive' -print -quit 2>/dev/null || true)"

if [[ -n "${UARCH:-}" ]] && has_cmd log; then
  log show --archive "$UARCH" --info --predicate "eventMessage CONTAINS[c] \"$IOC\"" --style syslog \
    > "$OUT_DIR/hits/unified_general.txt" 2>/dev/null || true

  log show --archive "$UARCH" --info --predicate 'process == "mDNSResponder" AND eventMessage CONTAINS[c] "'"$IOC"'"' --style syslog \
    > "$OUT_DIR/hits/unified_dns.txt" 2>/dev/null || true

  log show --archive "$UARCH" --info --predicate 'process == "trustd" AND eventMessage CONTAINS[c] "'"$IOC"'"' --style syslog \
    > "$OUT_DIR/hits/unified_tls.txt" 2>/dev/null || true

  for f in unified_general.txt unified_dns.txt unified_tls.txt; do
    [[ -s "$OUT_DIR/hits/$f" ]] || continue
    awk '
      BEGIN{FS="[[:space:]]+"}
      /^[0-9]{4}-[0-9]{2}-[0-9]{2}/{
        ts=$1" "$2; sub(/\..*/,"",ts);
        print ts "\t" "'"${f%.txt}"'" "\t" $0 "\t" "'"$UARCH"'"
      }' "$OUT_DIR/hits/$f" >> "$OUT_DIR/timeline.tsv" || true
  done
else
  echo "[*] No .logarchive found or 'log' tool unavailable; skipping unified logs."
fi

# -------------------- 7) Execution Forensics --------------------
echo "[*] Execution artifacts..."
if [[ -n "${UARCH:-}" ]] && has_cmd log; then
  log show --archive "$UARCH" --info --predicate "eventMessage CONTAINS[c] \"$IOC\" AND (eventMessage CONTAINS[c] \"exec\" OR eventMessage CONTAINS[c] \"launched\")" --style syslog \
    > "$OUT_DIR/hits/unified_exec.txt" 2>/dev/null || true

  if [[ -s "$OUT_DIR/hits/unified_exec.txt" ]]; then
    awk '
      BEGIN{FS="[[:space:]]+"}
      /^[0-9]{4}-[0-9]{2}-[0-9]{2}/{
        ts=$1" "$2; sub(/\..*/,"",ts);
        print ts "\t" "unified_exec" "\t" $0 "\t" "'"$UARCH"'"
      }' "$OUT_DIR/hits/unified_exec.txt" >> "$OUT_DIR/timeline.tsv" || true
  fi
else
  echo "[*] Unified logs unavailable; skipping execution search."
fi

# -------------------- 8) Sort timeline & write summary/report --------------------
{ read -r header; echo "$header"; sort -k1,1 -k2,2; } < "$OUT_DIR/timeline.tsv" > "$OUT_DIR/timeline.sorted.tsv" || true
mv "$OUT_DIR/timeline.sorted.tsv" "$OUT_DIR/timeline.tsv" || true

{
  echo "Mode      : IOC"
  echo "Search    : $IOC_DISP"
  echo "Phase-1   : $PHASE1_DIR"
  echo ""
  for f in "$OUT_DIR"/hits/*.txt; do
    [[ -e "$f" ]] || continue
    n="$(grep -ic -- "$IOC" "$f" 2>/dev/null || true)"
    [[ "$n" =~ ^[0-9]+$ ]] || n=0
    printf "%-32s : %s\n" "$(basename "$f")" "$n"
  done
} | tee "$OUT_DIR/summary.txt"

{
  echo "# mac_extract_phase2 report"
  echo ""
  echo "**Mode:** \`IOC\`  "
  echo "**Search:** \`$IOC_DISP\`  "
  echo "**Phase-1 folder:** \`$PHASE1_DIR\`  "
  echo ""
  echo "## Summary"
  echo '```'
  cat "$OUT_DIR/summary.txt"
  echo '```'
  echo ""
  echo "## Timeline (first 100 rows)"
  echo '```tsv'
  head -n 101 "$OUT_DIR/timeline.tsv"
  echo '```'
  echo ""
  echo "## Hit Files"
  for f in "$OUT_DIR"/hits/*.txt; do
    echo "- $(basename "$f")"
  done
} > "$OUT_DIR/report.md"

# -------------------- 9) Convert hit files to CSV --------------------
for f in "$OUT_DIR"/hits/*.txt; do
  [[ -e "$f" ]] || continue
  mv "$f" "${f%.txt}.csv"
done

echo ""
echo "=== DONE ==="
echo "Summary : $OUT_DIR/summary.txt"
echo "Timeline: $OUT_DIR/timeline.tsv"
echo "Report  : $OUT_DIR/report.md"
echo "Hits    : $OUT_DIR/hits/"
[[ -n "${WORK_TMP:-}" ]] && rm -rf "$WORK_TMP" || true
